<?php

namespace App\Http\Controllers\Callback;

use App\Http\Controllers\Controller;
use App\Http\Controllers\SMS\SMSController;
use Illuminate\Http\Request;

class CellulantController extends Controller
{
    //
    public function cellulantCallback(Request $req) {
        $string = $req->all();
        SMSController::sendMessage($string['requestStatusCode'], '0745681617');
        $decodedResponse = $req->all();
        if ($decodedResponse["requestStatusCode"] == 178) {
            /**
             * Write your code here
             * 1. Log the transaction to the database
             * 2. Validate the transaction
             * 3. respond back appropriately
             */
         

            $response = array(
                "statusCode" => 183,
                "statusDescription" => "Successful payment",
                "checkoutRequestID" => $decodedResponse["checkoutRequestID"],
                "merchantTransactionID" => $decodedResponse["merchantTransactionID"],
                "receiptNumber" => ""
            );
        } else {
            $response = array(
                "statusCode" => 180,
                "statusDescription" => "failed payment",
                "checkoutRequestID" => $decodedResponse["checkoutRequestID"],
                "merchantTransactionID" => $decodedResponse["merchantTransactionID"],
                "receiptNumber" => ""
            );
        }
        return response()->json($response);
    }

    public function vodacomCallback(Request $req) {
        $string = (string) $req->all();
        SMSController::sendMessage($string, '0745681617');
    }

    public function airtelCallback(Request $req) {
        $string = (string) $req->all();
        SMSController::sendMessage($string, '0745681617');
    }
}
