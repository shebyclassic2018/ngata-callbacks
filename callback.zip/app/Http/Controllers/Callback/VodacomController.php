<?php

namespace App\Http\Controllers\Callback;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Curl\CurlRequests;
use Illuminate\Http\Request;
use App\Http\Controllers\SMS\SMSController;

class VodacomController extends Controller
{
    public function CallbackReceiver(Request $req) {
        if ($req->input_ResponseCode === 'INS-0') {
           $data = array(
               'status_code' => $req->input_ResponseCode,
               "tpcconversation_id" =>  $req->input_ThirdPartyConversationID,
           );
           if(env('Message_Env') === 'local') {
                return CurlRequests::_curlpost('http://127.0.0.1:8001/request/vodacom-processor', $data);
           } else {
                return CurlRequests::_curlpost('http://openapi.ngata.co.tz/request/vodacom-processor', $data);
           }
        }
    }
}
