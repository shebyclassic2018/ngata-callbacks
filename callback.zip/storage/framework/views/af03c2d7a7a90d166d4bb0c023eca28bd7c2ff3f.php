
<?php $__env->startPush('css_before'); ?>
    <style>
    .home-page {
        height: calc(100% - 76px)
    }

    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="home-page flex pt-3">
        <div class="left-side-bar h-100 " style="width: 250px">
            <a class="dropdown-item text-center" href="#"><?php echo e(Auth::user()->name); ?></a>
            <a class="dropdown-item text-center" href="#"><?php echo e(Auth::user()->email); ?></a>
            <div class="dropdown-divider"></div>
            <?php echo $__env->yieldContent('left-content'); ?>
        </div>
        <div class="right-side-bar flex-1 overflow-auto" style="background: #fcfcfc">
            <?php echo $__env->yieldContent('right-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_after'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\open_api\resources\views/pages/home.blade.php ENDPATH**/ ?>