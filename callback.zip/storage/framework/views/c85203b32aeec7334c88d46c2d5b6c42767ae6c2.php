
<?php $__env->startPush('css_before'); ?>
    <style>
       
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <form id="login" action="<?php echo e(route('authenticate')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h1>Log In</h1>
        <fieldset id="inputs">
            <input type="hidden" name="agent" value="web">
            <input id="email" type="email" name="email" placeholder="Email address" autofocus required>
            <input id="password" name="password" type="password" placeholder="Password" required>
        </fieldset>
        <fieldset id="actions">
            <input type="submit" id="submit" value="Log in">
            <a href="#">Forgot your password?</a><a href="<?php echo e(route('register')); ?>">Register</a>
        </fieldset>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_after'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\open_api\resources\views/index.blade.php ENDPATH**/ ?>