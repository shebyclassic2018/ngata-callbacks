<script src="<?php echo e(asset('guest/js/jquery-3.3.1.min.js')); ?>" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script>
    var _token = "<?php echo e(csrf_token()); ?>";
</script>
<?php echo $__env->yieldPushContent('js_after'); ?>

</html>
<?php /**PATH D:\Projects\open_api\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>