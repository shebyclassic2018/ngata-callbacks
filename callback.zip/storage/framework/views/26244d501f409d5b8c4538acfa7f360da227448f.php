
<?php $__env->startPush('css_before'); ?>
    <style>
        input[readonly] {
            background-color: red;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', 'Admin'); ?>
<?php $__env->startSection('left-content'); ?>
    <a class="dropdown-item text-danger" href="<?php echo e(route('admin-page')); ?>"><i class="fa fa-dashboard" aria-hidden="true"></i>
        Dashboard</a>
    <a class="dropdown-item" href="<?php echo e(route('documentation')); ?>"><span class="fa fa-file"></span> API Documentation</a>
    <div class="dropdown-divider"></div>
    <a class="dropdown-item font-weight-bold" href="<?php echo e(route('logout')); ?>"><span class="fa fa-power-off"></span> Logout</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('right-content'); ?>
    <div class="block">
        <div class="block-header block-header-default">
            <div class="block-title fs-xs">Grant Access</div>
        </div>
        <form method="POST" action="<?php echo e(route('grant-permission')); ?>" class="block-content">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-8">
                    <input type="email" name="email" class="form-control fs-xs" placeholder="name@example.com" required> 
                </div>
                <div class="col-sm-4">
                    <button class="btn btn-success fs-xs">Grant permission</button>
                </div>
            </div><br>
            <?php if(\Session::get('message') === 'Verified'): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="alert alert-success">Permission granted</div>
                    </div>
                </div>
            <?php elseif(\Session::get('message') === 'Pending'): ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="alert alert-danger">Permission not granted</div>
                </div>
            </div>
            <?php elseif(\Session::get('message') == 'user not found'): ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="alert alert-info">User with email: <b><?php echo e(\Session::get('email')); ?></b> not found</div>
                </div>
            </div>
            <?php endif; ?>
            <br>
        </form>
    </div>

    <div class="block">
        <div class="block-header block-header-default">
            <div class="block-title fs-xs">Revoke Access</div>
        </div>
        <form method="POST" action="<?php echo e(route('revoke-permission')); ?>" class="block-content">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-8">
                    <input type="email" name="email" class="form-control fs-xs" placeholder="name@example.com" required> 
                </div>
                <div class="col-sm-4">
                    <button class="btn btn-warning fs-xs">Revoke permission</button>
                </div>
            </div><br>
            <?php if(\Session::get('messager') === 'Pending'): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="alert alert-success">Permission revoked</div>
                    </div>
                </div>
            <?php elseif(\Session::get('messager') === 'Verified'): ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="alert alert-danger">Permission not revoked</div>
                </div>
            </div>
            <?php elseif(\Session::get('messager') == 'user not found'): ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="alert alert-info">User with email: <b><?php echo e(\Session::get('email')); ?></b> not found</div>
                </div>
            </div>
            <?php endif; ?>
            <br>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_after'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\open_api\resources\views/pages/api-admin.blade.php ENDPATH**/ ?>