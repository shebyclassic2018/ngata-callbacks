<!-- Image and text -->
<div class="navbar" style="background: #00314a">
    <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('storage/image/favicon-192x192.png')); ?>" width="150" height="50"
            class="d-inline-block align-top" alt="">
    </a>
</div>

<?php /**PATH D:\Projects\open_api\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>