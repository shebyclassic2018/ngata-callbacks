<!-- Image and text -->
<div class="navbar" style="background: #00314a">
    <a class="navbar-brand" href="#">
        <img src="{{ asset('storage/image/favicon-192x192.png') }}" width="150" height="50"
            class="d-inline-block align-top" alt="">
    </a>
</div>
{{-- <h1 class="text-white pt-1 pb-1 flex-center" style="background: #014d74;">Ngata Open Api</h1> --}}
