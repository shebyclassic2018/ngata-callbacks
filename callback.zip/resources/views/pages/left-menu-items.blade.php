<a class="dropdown-item text-danger" href="{{ route('userKeys') }}"><i class="fa fa-dashboard" aria-hidden="true"></i>
    Dashboard</a>
<a class="dropdown-item" href="{{ route('documentation') }}"><span class="fa fa-file"></span> API Documentation</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item font-weight-bold" href="{{route('logout')}}"><span class="fa fa-power-off"></span> Logout</a>
